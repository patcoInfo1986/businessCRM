var ib_save_state_data = function(){/*
<ib-div class="ib_modal_container">
  <ib-div class="ib_p">
    Esta accion guardara el estado actual de la plantilla en un archivo local llamado <ib-span class="ib_code">data.txt</ib-span>. Los datos de este asrchivo seran usados para rellenar los campos de la plantilla previamente en el futuro. Esto ocurre cuando quieres guardar los datos predeterminados como ubicacion de la empresa, logotipo, moneda, notas para no volver a escribirlos cada vez.
  </ib-div>

  <ib-div class="ib_p">
    Despues de hacer clic en el boton de abajo, se le preguntara si deseas guardar el archivo.
  </ib-div>

  <ib-div class="ib_p ib_b">
    No se olvide de dar nombre a este archivo <ib-span class="ib_code">data.txt</ib-span> y guardarlo en la carpeta de plantillas. Si el archivo ya existe, sobrescribalo.
  </ib-div>

  <ib-div class="ib_p ib_notice">
    <ib-span class="ib_b">Nota:</ib-span> Guardando el estado de la plantilla no pretende memorizar un ejemplo real de la factura para el mantenimiento de registros. Por esto tu debes o <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/H8s1yUCXnj4', '_blank')">guardar la factura en PDF</ib-span> (by using the Print option) o <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/EfafX6izKxc', '_blank')">guardarla online</ib-span>.
  </ib-div>

  <a href="javascript:void(0);" download="data.txt" class="ib_default_button ib_success_button ib_large_button" id="ib-save-current-data"><ib-span class="fa fa-bolt"></ib-span> Guarda los data.txt</a>
  <ib-div id="ib-safari-save-as" class="ib_hide ib_safari_note">Clica con el boton derecho y selecciona <ib-span class="ib_b">&quot;Descargar Archivo Enlazado Como...&quot;</ib-span></ib-div>
</ib-div>
*/}
