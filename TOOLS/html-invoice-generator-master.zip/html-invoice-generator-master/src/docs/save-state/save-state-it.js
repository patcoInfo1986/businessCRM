var ib_save_state_data = function(){/*
<ib-div class="ib_modal_container">
  <ib-div class="ib_p">
    Questa azione salvera lo stato corrente del modello in un archivio locale chiamato <ib-span class="ib_code">data.txt</ib-span>. I dati di questo archivio saranno usati per completare i campi del modello nel futuro. Questo avviene a portata di mano quando vuoi salvare i dettagli predefiniti come indirizzo dell'azienda, logo, valuta, note, ecc., per non scriverli di nuovo ogni volta.
  </ib-div>

  <ib-div class="ib_p">
    Dopo aver cliccato sul bottone qui sotto, verra chiesto di salvare l'archivio.
  </ib-div>

  <ib-div class="ib_p ib_b">
    Non dimenticare di dare nome a questo archivio <ib-span class="ib_code">data.txt</ib-span> e salvarlo nella cartella dei modelli. Se l'archivio esiste gia, sovrascrivilo.
  </ib-div>

  <ib-div class="ib_p ib_notice">
    <ib-span class="ib_b">Nota:</ib-span> Salvando lo stato del modello non e destinato a memorizzare un'istanza effettiva della fattura per la tenuta dei registri. Per questo, tu devi o <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/H8s1yUCXnj4', '_blank')">salvare il modello in PDF</ib-span> (usando l'opzione Print) o <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/EfafX6izKxc', '_blank')">salvarlo online</ib-span>.
  </ib-div>

  <a href="javascript:void(0);" download="data.txt" class="ib_default_button ib_success_button ib_large_button" id="ib-save-current-data"><ib-span class="fa fa-bolt"></ib-span> Salva i dati.txt</a>
  <ib-div id="ib-safari-save-as" class="ib_hide ib_safari_note">Clicca con il tasto destro e scegli <ib-span class="ib_b">&quot;Scaricare File Collegato Come...&quot;</ib-span></ib-div>
</ib-div>
*/}
