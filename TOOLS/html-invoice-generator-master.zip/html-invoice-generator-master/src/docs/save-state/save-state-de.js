var ib_save_state_data = function(){/*
<ib-div class="ib_modal_container">
  <ib-div class="ib_p">
    Diese aktion wird den aktuellen status der vorlage zu einer lokalen datei mit dem namen <ib-span class="ib_code">data.txt</ib-span> speichern. Die daten aus dieser datei verwendet werden, um die schablonenfelder in zukunft vorab auszufüllen. Dies ist praktisch, wenn sie ihre standard-details zu speichern möchten, wie firmenadresse, logo, währung, notizen, usw., so dass sie nicht brauchen, sie jedes mal neu eingeben.
  </ib-div>

  <ib-div class="ib_p">
    Nach einem klick auf die schaltfläche unten, werden sie die datei zu speichern aufgefordert.
  </ib-div>

  <ib-div class="ib_p ib_b">
    Achten sie darauf, diese datei zu benennen <ib-span class="ib_code">data.txt</ib-span> und es in der vorlage verzeichnis speichern. Wenn die datei bereits vorhanden ist, überschrieben.
  </ib-div>

  <ib-div class="ib_p ib_notice">
    <ib-span class="ib_b">Hinweis:</ib-span> Speichern der zustand der vorlage ist nicht beabsichtigt, eine tatsächliche instanz der rechnung für die aufzeichnung zu speichern. Dazu sollten sie entweder <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/H8s1yUCXnj4', '_blank')">um die rechnung zu PDF speichern</ib-span> (durch die option drucken mit) oder <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/EfafX6izKxc', '_blank')">speichern sie es online</ib-span>.
  </ib-div>

  <a href="javascript:void(0);" download="data.txt" class="ib_default_button ib_success_button ib_large_button" id="ib-save-current-data"><ib-span class="fa fa-bolt"></ib-span> Speichern data.txt</a>
  <ib-div id="ib-safari-save-as" class="ib_hide ib_safari_note">Rechts auf die schaltfläche klicken, und wählen sie <ib-span class="ib_b">&quot;Verknüpfte Datei Laden Unter...&quot;</ib-span></ib-div>
</ib-div>
*/}
