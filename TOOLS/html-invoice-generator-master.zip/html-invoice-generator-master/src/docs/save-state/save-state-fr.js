var ib_save_state_data = function(){/*
<ib-div class="ib_modal_container">
  <ib-div class="ib_p">
    Cette action sauvegardera l'état actuel du template dans un documant local appelé <ib-span class="ib_code">data.txt</ib-span>. Les données de ce document seront utilisées pour to pré-peupler les champs du template dans l'avenir. Cela représente une aide quand vous voulez sauvegarder vos détails de  défaut tels que l'adresse,le logo de l'entreprise, la monnaie,les notes, etc., alors vous n'avez pas besoin de les taper chaque fois de nouveau.
  </ib-div>

  <ib-div class="ib_p">
    Après avoir cliqué sur la touche en bas,vous serez incité à sauvegarder le document.
  </ib-div>

  <ib-div class="ib_p ib_b">
    N'oubliez pas à donner un nom au document <ib-span class="ib_code">data.txt</ib-span> et à le sauvegarder dans le directoire du template. Si le document existe déjà, récrivez-le.
  </ib-div>

  <ib-div class="ib_p ib_notice">
    <ib-span class="ib_b">Note:</ib-span> Sauvegarder l'état du template ne veut pas dire garder une instance actuelle de la facture pour le dossier. Pour cela,vous devriez soit <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/H8s1yUCXnj4', '_blank')">sauvegarder la facture sous PDF</ib-span> (en utilisant l'option Imprimer) ou <ib-span class="ib_a" onclick="window.open('https://groups.google.com/forum/#!topic/html-invoice-generator/EfafX6izKxc', '_blank')">sauvegarder en ligne</ib-span>.
  </ib-div>
  
  <a href="javascript:void(0);" download="data.txt" class="ib_default_button ib_success_button ib_large_button" id="ib-save-current-data"><ib-span class="fa fa-bolt"></ib-span> Enregistrer data.txt</a>
  <ib-div id="ib-safari-save-as" class="ib_hide ib_safari_note">Droit cliquez la touche et choisissez <ib-span class="ib_b">&quot;Télécharger Le Fichier Lié Sous...&quot;</ib-span></ib-div>
</ib-div>
*/}
